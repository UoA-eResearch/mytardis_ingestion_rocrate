"""
Constants for MyTardis API configuration.
These will be used as default if an alternative is not provided via CLI
"""
from mytardis_rocrate_builder.rocrate_dataclasses.rocrate_dataclasses import Organisation

CONNECTION__HOSTNAME = "https://test-instruments.nectar.auckland.ac.nz//"
CONNECTION__PROXY__HTTP = ""
CONNECTION__PROXY__HTTPS = ""

UOA = Organisation(
    identifiers=["https://ror.org/03b94tp07"],
    name="The University of Auckland | Waipapa Taumata Rau",
    url="https://auckland.ac.nz",
    location="Auckland, New Zealand",
    research_org=True,
)
