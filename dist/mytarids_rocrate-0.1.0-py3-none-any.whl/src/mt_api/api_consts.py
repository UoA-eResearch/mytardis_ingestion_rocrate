"""
Constants for MyTardis API configuration.
These will be used as default if an alternative is not provided via CLI
"""

CONNECTION__HOSTNAME = "https://test-instruments.nectar.auckland.ac.nz//"
CONNECTION__PROXY__HTTP = ""
CONNECTION__PROXY__HTTPS = ""
