"""RO-Crate objects represented as Dataclasses"""
