"""Functions to access the Active directory and get user details from UPI"""
